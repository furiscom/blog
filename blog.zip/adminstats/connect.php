<?php
$dsn='mysql:host=sql107.epizy.com;dbname=epiz_32063989_db_masjid';//dbname and host
$username='epiz_32063989';//username
$password='ov4oUptNc4E';//password
?>