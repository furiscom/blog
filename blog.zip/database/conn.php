<?php
//database connection
($GLOBALS["___mysqli_ston"] = mysqli_connect("sql107.epizy.com","epiz_32063989","ov4oUptNc4E","epiz_32063989_db_masjid"));  //host,user,password,database
?>
