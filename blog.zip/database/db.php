<?php
	$database_username = 'epiz_32063989';//user name
	$database_password = 'ov4oUptNc4E';//password
	$pdo_conn = new PDO( 'mysql:host=sql107.epizy.com;dbname=epiz_32063989_db_masjid', $database_username, $database_password );
?>
