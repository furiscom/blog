<?php
$con=mysqli_connect("sql107.epizy.com","epiz_32063989","ov4oUptNc4E","epiz_32063989_db_masjid");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 ?>
