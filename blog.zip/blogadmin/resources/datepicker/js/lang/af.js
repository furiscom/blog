var fdLocale = {
        months:[
                "Januarie",
                "Februarie",
                "Maart",
                "April",
                "Mei",
                "Junie",
                "Julie",
                "Augustus",
                "September",
                "Oktober",
                "November",
                "Desember"
                ],
        fullDay:[
                "Maandag",
                "Dinsdag",
                "Woensdag",
                "Donderdag",
                "Vrydag",
                "Saterdag",
                "Sondag"
                ],
        /* Only stipulate the dayAbbr should the first letter of the fullDay not suffice

        dayAbbr:[],
        */

        /* Only stipulate the firstDayOfWeek should the first day not be Monday

        firstDayOfWeek:0,
        */
        titles:[
                "Vorige maand",
                "Volgende maand",
                "Vorige jaar",
                "Volgende jaar"
                ]
};
